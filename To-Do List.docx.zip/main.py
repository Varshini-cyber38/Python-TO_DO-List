import json
from pathlib import Path


class TodoManager:
    """Manage tasks and save them locally in a JSON file."""

    def __init__(self, file_name="tasks.json"):
        # Store data beside this script so the app works from any terminal folder.
        self.file_path = Path(__file__).parent / file_name
        self.tasks = []
        self.load_tasks()

    def load_tasks(self):
        """Load saved tasks. Start with an empty list if no file exists yet."""
        if not self.file_path.exists():
            self.tasks = []
            return

        try:
            with self.file_path.open("r", encoding="utf-8") as file:
                data = json.load(file)
            # Avoid crashing if the JSON file does not contain a list.
            self.tasks = data if isinstance(data, list) else []
        except (json.JSONDecodeError, OSError):
            print("Warning: Could not read saved tasks. Starting with an empty list.")
            self.tasks = []

    def save_tasks(self):
        """Save the current task list to disk."""
        try:
            with self.file_path.open("w", encoding="utf-8") as file:
                json.dump(self.tasks, file, indent=4)
        except OSError:
            print("Error: Tasks could not be saved.")

    def add_task(self, title):
        """Add a task with a unique ID and an incomplete status."""
        next_id = max((task["id"] for task in self.tasks), default=0) + 1
        self.tasks.append({"id": next_id, "title": title, "completed": False})
        self.save_tasks()
        print(f'Task added successfully (ID: {next_id}).')

    def view_tasks(self):
        """Display all tasks or a message when no tasks exist."""
        if not self.tasks:
            print("No tasks found. Add a task to get started.")
            return

        print("\n--- Your To-Do List ---")
        for task in self.tasks:
            status = "Completed" if task["completed"] else "Pending"
            print(f'ID: {task["id"]} | {task["title"]} | {status}')
        print()

    def mark_completed(self, task_id):
        """Mark the task with the given ID as completed."""
        task = self.find_task(task_id)
        if task is None:
            print("Task ID not found.")
            return

        if task["completed"]:
            print("This task is already completed.")
            return

        task["completed"] = True
        self.save_tasks()
        print("Task marked as completed.")

    def remove_task(self, task_id):
        """Remove a task by its ID."""
        task = self.find_task(task_id)
        if task is None:
            print("Task ID not found.")
            return

        self.tasks.remove(task)
        self.save_tasks()
        print("Task removed successfully.")

    def find_task(self, task_id):
        """Return a task by ID, or None if it does not exist."""
        for task in self.tasks:
            if task["id"] == task_id:
                return task
        return None


def read_task_id():
    """Read and validate a task ID from the user."""
    value = input("Enter task ID: ").strip()
    try:
        task_id = int(value)
        if task_id <= 0:
            print("Please enter a positive task ID.")
            return None
        return task_id
    except ValueError:
        print("Invalid input. Task ID must be a number.")
        return None


def show_menu():
    """Display the main menu."""
    print("\n===== To-Do List Manager =====")
    print("1. Add task")
    print("2. View tasks")
    print("3. Mark task as completed")
    print("4. Remove task")
    print("5. Exit")


def main():
    manager = TodoManager()

    while True:
        show_menu()
        choice = input("Choose an option (1-5): ").strip()

        if choice == "1":
            title = input("Enter task title: ").strip()
            if not title:
                print("Task title cannot be empty.")
            else:
                manager.add_task(title)
        elif choice == "2":
            manager.view_tasks()
        elif choice == "3":
            task_id = read_task_id()
            if task_id is not None:
                manager.mark_completed(task_id)
        elif choice == "4":
            task_id = read_task_id()
            if task_id is not None:
                manager.remove_task(task_id)
        elif choice == "5":
            print("Thank you for using the To-Do List Manager.")
            break
        else:
            print("Invalid choice. Please select a number from 1 to 5.")


if __name__ == "__main__":
    try:
        main()
    except (KeyboardInterrupt, EOFError):
        print("\nApplication closed.")
